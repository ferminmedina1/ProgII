package Parcialito4;

public interface Criterio{
	boolean cumple(Pelicula p);
}
