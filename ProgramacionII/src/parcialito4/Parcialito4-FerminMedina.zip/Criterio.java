package parcialito4;

public interface Criterio{
	boolean cumple(pelicula p);
}
