package parcialito4;


public class CriterioGenero implements Criterio {

	private String palabra;
	
	public CriterioGenero(String palabra) {
		this.palabra = palabra.toUpperCase();
	}
	
	@Override
	public boolean cumple(pelicula p) {
		if(p.getGeneros().contains(palabra)) {
			return true;
		}
		return false;
	}

}
