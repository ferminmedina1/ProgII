package parcialito4;

public class CriterioTituloContiene implements Criterio{

	private String palabra;
	
	
	public CriterioTituloContiene(String palabra) {
		this.palabra = palabra.toUpperCase();
	}


	@Override
	public boolean cumple(pelicula p) {
		return p.getTitulo().contains(palabra);
	}
}
