package parcialito4;

import java.util.ArrayList;

public class Plataforma {
	
	private ArrayList<pelicula> peliculas;
	
	public Plataforma() {
		this.peliculas = new ArrayList<pelicula>();
	}
	
	public boolean isRentable(pelicula p,Criterio c1, Criterio c2) {
		if(c1.cumple(p) && c2.cumple(p))
			return true;
					
		return false;
	}
	
	public void addPelicula(pelicula p) {
		if(!peliculas.contains(p)) {
			peliculas.add(p);
		}else {
			System.out.println("esa Pelicula ya estaba en la plataforma");
		}
	}
	
	public ArrayList<pelicula> mostrarConTitulo(Criterio c) {
		ArrayList<pelicula> p = new ArrayList<pelicula>();
		for (pelicula pelicula : this.peliculas) {
			if(c.cumple(pelicula)) {
				p.add(pelicula);
			}
		}
		return p;
	}
	
	public ArrayList<pelicula> mostrarConGenero(Criterio c) {
		ArrayList<pelicula> p = new ArrayList<pelicula>();
		for (pelicula pelicula : this.peliculas) {
			if(c.cumple(pelicula)) {
				p.add(pelicula);
			}
		}
		return p;
	}

	public ArrayList<pelicula> mostrarConWillSinMartin(Criterio c) {
		ArrayList<pelicula> p = new ArrayList<pelicula>();
		for (pelicula pelicula : this.peliculas) {
			if(c.cumple(pelicula)) {
				p.add(pelicula);
			}
		}
		return p;
	}
	
	public ArrayList<pelicula> mostrarAntesDeYduracionDe(Criterio c) {
		ArrayList<pelicula> p = new ArrayList<pelicula>();
		for (pelicula pelicula : this.peliculas) {
			if(c.cumple(pelicula)) {
				p.add(pelicula);
			}
		}
		return p;
	}

}
