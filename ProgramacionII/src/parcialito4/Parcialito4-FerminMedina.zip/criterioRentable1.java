package parcialito4;

public class criterioRentable1 implements Criterio {

	private int duracion;
	private String genero;
	
	public criterioRentable1(int duracion, String genero) {
		this.duracion = duracion;
		this.genero = genero.toUpperCase();
	}
	
	@Override
	public boolean cumple(pelicula p) {
		if(p.getDuracion() < duracion && !p.getGeneros().contains(genero)) {
			return true;
		}
		return false;
	}

}
